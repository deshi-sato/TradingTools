---
title: 変更履歴
---

# 変更履歴（主要差分）

| 日付 | 内容 | 対象 |
|------|------|------|
| 2025-10-09 | BUY閾値を0.6に更新 | stream_microbatch.py |
| 2025-10-09 | Start-microbatch.ps1 前景実行テスト | PowerShell |
| 2025-10-09 | SELL閾値GridSearch実装準備 | Python |
| 2025-10-08 | fallback_scraper 呼出し修正 | PS1 |
