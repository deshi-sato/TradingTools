---
title: 未完タスク
---

# 未完タスク一覧

## 優先度 高
- [ ] SELL閾値のGridSearch統合
- [ ] BUY/SELL両閾値の勝率比較

## 優先度 中
- [ ] PUSH例外処理のログ拡充
- [ ] Naut_runner統合テスト
- [ ] fallback_scraper の再検証

## 優先度 低
- [ ] ノート自動生成スクリプト化
- [ ] DendronノートとChatGPT連携の検証
