---
id: root
title: root
desc: ""
updated: 1605266684036
created: 1595961348801
---

This is the root for your Dendron vault.

If you decide to publish your entire vault, it will be your landing page. You are free to customize any part of this page except the frontmatter at the top, between the `---`.
